const playlistCollection = [
  {
    id: "01",
    title: "Beethoven Sonatas",
    songs: [
      {
        id: "04",
        title: "Piano Sonata No. 3",
        artist: "Beethoven",
      },
      {
        id: "05",
        title: "Piano Sonata No. 7",
        artist: "Beethoven",
      },
      {
        id: "06",
        title: "Piano Sonata No. 10",
        artist: "Beethoven",
      }
    ]
  },
  {
    id: "02",
    title: "Beethoven Concertos",
    songs: [
      {
        id: "07",
        title: "Piano Concerto No. 0",
        artist: "Beethoven",
      },
      {
        id: "08",
        title: "Piano Concerto No. 4",
        artist: "Beethoven",
      },
      {
        id: "09",
        title: "Piano Concerto No. 6",
        artist: "Beethoven",
      }
    ]
  },
  {
    id: "03",
    title: "Beethoven Variations",
    songs: [
      {
        id: "10",
        title: "Opus 34: Six variations on a theme in F major",
        artist: "Beethoven",
      },
      {
        id: "11",
        title: "Opus 120: Thirty-three variations on a waltz by Diabelli in C major",
        artist: "Beethoven",
      }
    ]
  },
  {
    id: "04",
    title: "Beethoven Symphonies",
    songs: [
      {
        id: "12",
        title: "Opus 21: Symphony No. 1 in C major",
        artist: "Beethoven",
      },
      {
        id: "13",
        title: "Opus 36: Symphony No. 2 in D major",
        artist: "Beethoven",
      },
       {
        id: "14",
        title: "Opus 55: Symphony No. 3 in E flat major",
        artist: "Beethoven",
      },
              {
        id: "15",
        title: "Opus 60: Symphony No. 4 in B flat major",
        artist: "Beethoven",
      }
    ]
  }
];

// EXERCISES:

// EXERCISE 1: Find the total number of playlists in the collection and log this to the console

let numplaylists = 0; 

for (let i = 0; i < playlistCollection.length; i++) {
  numplaylists++;
}

console.log("There are " + numplaylists + " playlists in the collection");


// EXERCISE 2: Find the total number of songs in the collection and log this to the console

let numsongs = 0;

for (let i = 0; i < playlistCollection.length; i++) {
    for (let j=0; j < playlistCollection[i].songs.length; j++) {
      numsongs++;
  }
}

console.log("There are " + numsongs + " songs in the collection");


// EXERCISE 3: Find the average number of songs across all playlist and log this to the console

let average = numsongs/numplaylists;

console.log("On average, there are " + average + " songs in each playlist");


// EXERCISE 4: Find the playlist with the most songs and log this to the console

let currentLargest = 0;
let largestPlaylistTitle = "";

for (let i = 0; i < playlistCollection.length; i++) {
    
    if(playlistCollection[i].songs.length > currentLargest){
        currentLargest = playlistCollection[i].songs.length;
        largestPlaylistTitle = playlistCollection[i].title;
    }
       
}

console.log("The playlist with the most songs is " + largestPlaylistTitle + "; it has " + currentLargest + " songs");


// EXERCISE 5: Find the playlist with the least songs and log this to the console

let currentSmallest = playlistCollection[0].songs.length;
let smallestPlaylistTitle = playlistCollection[0].title;

for (let i = 0; i < playlistCollection.length; i++) {
    
    if(playlistCollection[i].songs.length < currentSmallest){
        currentSmallest = playlistCollection[i].songs.length;
        smallestPlaylistTitle = playlistCollection[i].title;
    }
       
}

console.log("The playlist with the least songs is " + smallestPlaylistTitle + "; it has " + currentSmallest + " songs");